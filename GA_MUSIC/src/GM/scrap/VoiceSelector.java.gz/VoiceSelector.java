package GM.scrap;
import GM.jsyn.*;
import GM.io.*;
import GM.music.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import GM.javasound.*;

public class VoiceSelector {

    public VoiceSelector(Hub pallete) {
//     	this.band = context;
	    lastDir = new File("/home/pjl/code/MyProjects/Drum/samples");
    }

    public Voice selectVoice(Component parent) throws Exception {
	JFileChooser fc = new JFileChooser();
	fc.setCurrentDirectory(lastDir);
	int returnVal = fc.showOpenDialog(parent);

	if (returnVal == JFileChooser.APPROVE_OPTION) {
	    String names[] = null;//God.theGeneIO().getSampleNames();
	    lastDir = fc.getCurrentDirectory();
	    try {
	    return null; /** @todo (new Sample(band.getConductor(),names[0],names[0])); */
	    }catch(Exception e) {
		System.err.println(e);System.exit(-1);
		return null;
	    }
	} else {
	    return null;
	    //                }
	}

    }

    private File    lastDir;
//    private Band band;

}
