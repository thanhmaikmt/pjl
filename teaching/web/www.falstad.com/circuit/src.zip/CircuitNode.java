import java.util.Vector;

class CircuitNode {
    int x, y;
    Vector links;
    boolean internal;
    CircuitNode() { links = new Vector(); }
}
