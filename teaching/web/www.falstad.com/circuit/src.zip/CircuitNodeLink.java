    class CircuitNodeLink {
	int num;
	CircuitElm elm;
    }
